
Note:

For the "PathPlannerApp", you must open a collision map file before hitting the triangle "Start" button.

